
<?php $__env->startSection('content'); ?>
    <div id="main-content">
        <div class="container-fluid">
            <div class="block-header">
                <div class="row">
                    <div class="col-12">
                        <h2 class="float-left">Akun</h2>
                        <button type="button" class="btn btn-sm btn-primary float-right" data-toggle="modal"
                            data-target="#add-akun">
                            <i class="fa fa-plus-circle"></i>
                            Tambah Akun
                        </button>
                        
                    </div>
                    
                </div>
            </div>

            <div class="row clearfix row-deck">

                <div class="table-responsive">
                    <table class="table js-basic-example dataTable table-custom" id="table">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Akun</th>
                                <th>Jenis Akun</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                                $i = 1;
                            ?>
                            <?php $__currentLoopData = $akun; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    
                                    <td><?php echo e($i++); ?></td>
                                    <td><?php echo e($a->nm_akun); ?></td>
                                    <td><?php echo e($a->jenisAkun->jenis_akun); ?></td>
                                    <td>
                                        <button type="button" class="btn btn-sm btn-primary" data-toggle="modal"
                                            data-target="#edit-akun<?php echo e($a->id); ?>">
                                            <i class="fa fa-edit"></i>
                                        </button>

                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </tbody>
                    </table>
                </div>

            </div>


        </div>
    </div>


    <form action="<?php echo e(route('addAkun')); ?>" method="post">
        <?php echo csrf_field(); ?>
        <div class="modal fade" id="add-akun" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Tambah Akun</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">

                        <div class="row">

                            <div class="col-12">
                                <label>Nama Akun</label>
                                <input type="text" name="nm_akun" class="form-control" placeholder="Masukan barang"
                                    required>
                            </div>

                            <div class="col-12">
                                <label>Jenis Akun</label>
                                <select class="form-control select2bs4" name="jenis_akun_id" required>
                                    <option value="">-Pilih Jenis-</option>
                                    <?php $__currentLoopData = $jenis_akun; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $j): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($j->id); ?>"><?php echo e($j->jenis_akun); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>


                        </div>

                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary">Tambah</button>
                    </div>
                </div>
            </div>
        </div>
    </form>

    <?php $__currentLoopData = $akun; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <form action="<?php echo e(route('editAkun')); ?>" method="post">
            <?php echo csrf_field(); ?>
            <?php echo method_field('patch'); ?>
            <div class="modal fade" id="edit-akun<?php echo e($a->id); ?>" role="dialog" aria-labelledby="exampleModalLabel"
                aria-hidden="true">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLabel">Tambah Akun</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body">

                            <div class="row">
                                <input type="hidden" name="id" value="<?php echo e($a->id); ?>">
                                <div class="col-12">
                                    <label>Nama Akun</label>
                                    <input type="text" name="nm_akun" class="form-control" placeholder="Masukan barang"
                                        value="<?php echo e($a->nm_akun); ?>" required>
                                </div>

                                <div class="col-12">
                                    <label>Jenis Akun</label>
                                    <select class="form-control select2bs4" name="jenis_akun_id" required>
                                        <?php $__currentLoopData = $jenis_akun; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $j): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($j->id); ?>"
                                                <?php echo e($a->jenis_akun_id == $j->id ? 'selected' : ''); ?>><?php echo e($j->jenis_akun); ?>

                                            </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>

                            </div>

                            <?php if($a->jenis_akun_id == 3 || $a->jenis_akun_id == 5): ?>
                                <table class="table-sm" width="100%">
                                    <thead>
                                        <tr>
                                            <th>Cabang</th>
                                            <th>Jenis</th>
                                            <th>Jumlah</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $cabang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($k->nama); ?></td>

                                                <?php if($a->persenPengeluaran): ?>
                                                    <?php
                                                        $data_persen = $a->persenPengeluaran
                                                            ->where('cabang_id', $k->id)
                                                            ->first();
                                                    ?>
                                                    <?php if($data_persen): ?>
                                                        <input type="hidden" name="persen_id[]"
                                                            value="<?php echo e($data_persen->id); ?>">
                                                        <td>
                                                            <select name="jenis_edit[]" class="form-control form-control-sm"
                                                                required>

                                                                <option value="1"
                                                                    <?php echo e($data_persen->jenis == 1 ? 'selected' : ''); ?>>Persen
                                                                </option>
                                                                <option value="2"
                                                                    <?php echo e($data_persen->jenis == 2 ? 'selected' : ''); ?>>Rupiah
                                                                </option>
                                                            </select>

                                                        </td>
                                                        <td>
                                                            <input type="text" name="jumlah_edit[]"
                                                                class="form-control form-control-sm"
                                                                value="<?php echo e($data_persen->jumlah); ?>" required>
                                                        </td>
                                                    <?php else: ?>
                                                        <input type="hidden" name="cabang_id[]"
                                                            value="<?php echo e($k->id); ?>">
                                                        <td>
                                                            <select name="jenis[]" class="form-control form-control-sm"
                                                                required>
                                                                <option value="1">Persen</option>
                                                                <option value="2">Rupiah</option>
                                                            </select>
                                                        </td>
                                                        <td>
                                                            <input type="text" name="jumlah[]"
                                                                class="form-control form-control-sm">
                                                        </td>
                                                    <?php endif; ?>
                                                <?php else: ?>
                                                    <input type="hidden" name="cabang_id[]"
                                                        value="<?php echo e($k->id); ?>">
                                                    <td>
                                                        <select name="jenis[]" class="form-control form-control-sm"
                                                            required>
                                                            <option value="1">Persen</option>
                                                            <option value="2">Rupiah</option>
                                                        </select>
                                                    </td>
                                                    <td>
                                                        <input type="text" name="jumlah[]"
                                                            class="form-control form-control-sm">
                                                    </td>
                                                <?php endif; ?>

                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </tbody>
                                </table>
                            <?php endif; ?>


                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                            <button type="submit" class="btn btn-primary">Edit</button>
                        </div>
                    </div>
                </div>
            </div>
        </form>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



<?php $__env->startSection('script'); ?>
    <script>
        $(document).ready(function() {

            <?php if(session('success')): ?>
            // notification popup
            toastr.options.closeButton = true;
            toastr.options.positionClass = 'toast-top-right';
            toastr.options.showDuration = 1000;
            toastr['success']('<?= session('success') ?>');
            <?php endif; ?>


        });
    </script>
<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\programming\monitoring-pengukuran\resources\views/akun/index.blade.php ENDPATH**/ ?>