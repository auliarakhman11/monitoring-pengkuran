
<?php $__env->startSection('content'); ?>
    <div id="main-content">
        <div class="container-fluid">
            <div class="block-header">
                <div class="row">
                    <div class="col-12">
                        <h2 class="float-left">Loket Pengukuran</h2>
                        <button type="button" class="btn btn-sm btn-primary float-right ml-2" data-toggle="modal"
                            data-target="#modal_tambah">
                            <i class="fa fa-plus-circle"></i>
                            Tambah Data
                        </button>
                        
                    </div>
                    
                </div>
            </div>

            <div class="row justify-content-center clearfix row-deck">
                <div class="col-12">
                    <div class="table-responsive">
                        <table class="table js-basic-example dataTable table-custom" id="table">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Berkas</th>
                                    <th>Pemohon</th>
                                    <th>Kelurahan</th>
                                    <th>Alamat</th>
                                    <th>No WA</th>
                                    <th>Tanggal</th>
                                    <th>Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                    $i = 1;
                                ?>
                                <?php $__currentLoopData = $berkas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($i++); ?></td>
                                        <td><?php echo e($d->no_berkas); ?> / <?php echo e($d->tahun); ?></td>
                                        <td><?php echo e($d->nm_pemohon); ?></td>
                                        <td><?php echo e($d->kelurahan); ?></td>
                                        <td><?php echo e($d->alamat); ?></td>
                                        <td><?php echo e($d->no_tlp); ?></td>
                                        <td><?php echo e(date('d/m/Y', strtotime($d->tgl))); ?></td>
                                        <td>
                                            <button type="button" class="btn btn-sm btn-primary" data-toggle="modal"
                                                data-target="#model_edit<?php echo e($d->id); ?>">
                                                <i class="fa fa-edit"></i>
                                            </button>

                                            <?php if($d->file_name): ?>
                                                <button type="button" class="btn btn-sm btn-primary btn_lihat_file"
                                                    data-toggle="modal" file_name="<?php echo e($d->file_name); ?>"
                                                    jenis_file="<?php echo e($d->jenis_file); ?>" data-target="#model_lihat_file">
                                                    <i class="fa fa-eye"></i>
                                                </button>
                                            <?php endif; ?>

                                            
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </tbody>
                        </table>
                    </div>
                </div>


            </div>

        </div>
    </div>


    <form action="<?php echo e(route('addBerkas')); ?>" method="post" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <div class="modal fade" id="modal_tambah" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
            aria-hidden="true">
            <div class="modal-dialog modal-xl" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Tambah Berkas</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">

                        <div class="row">

                            <div class="col-md-4 col-12">
                                <div class="form-group">
                                    <label for="">Tanggal Input</label>
                                    <input type="date" value="<?php echo e(date('Y-m-d')); ?>" class="form-control" name="tgl"
                                        required>
                                </div>
                            </div>

                            <div class="col-md-4 col-12">
                                <div class="form-group">
                                    <label for="">Nomor Berkas</label>
                                    <input type="text" class="form-control" name="no_berkas" required>
                                </div>
                            </div>

                            <div class="col-md-4 col-12">
                                <div class="form-group">
                                    <label for="">Tahun</label>
                                    <input type="text" class="form-control" name="tahun" required>
                                </div>
                            </div>

                            <div class="col-md-4 col-12">
                                <div class="form-group">
                                    <label for="">Nama Pemohon</label>
                                    <input type="text" class="form-control" name="nm_pemohon" required>
                                </div>
                            </div>

                            <div class="col-md-4 col-12">
                                <div class="form-group">
                                    <label for="">Kelurahan/Desa</label>
                                    <input type="text" class="form-control" name="kelurahan" required>
                                </div>
                            </div>

                            <div class="col-md-4 col-12">
                                <div class="form-group">
                                    <label for="">Nomor WA</label>
                                    <input type="number" class="form-control" name="no_tlp" required>
                                </div>
                            </div>

                            <div class="col-md-4 col-12">
                                <div class="form-group">
                                    <label for="">Alamat Bidang Tanah</label>
                                    <textarea class="form-control" name="alamat" cols="30" rows="3"></textarea>
                                </div>
                            </div>

                            <div class="col-md-4 col-12">
                                <div class="form-group">
                                    <label for="">Upload File</label>
                                    <input type="file" name="file_name" class="form-control"
                                        accept="application/pdf, image/png, image/jpeg">
                                </div>
                            </div>


                        </div>

                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary">Tambah</button>
                    </div>
                </div>
            </div>
        </div>
    </form>

    <?php $__currentLoopData = $berkas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <form action="<?php echo e(route('editBerkas')); ?>" method="post">
            <?php echo csrf_field(); ?>
            <?php echo method_field('patch'); ?>
            <div class="modal fade" id="model_edit<?php echo e($d->id); ?>" tabindex="-1" role="dialog"
                aria-labelledby="exampleModalLabel" aria-hidden="true">
                <div class="modal-dialog modal-xl" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLabel">Edit Berkas</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body">

                            <div class="row">

                                <input type="hidden" name="id" value="<?php echo e($d->id); ?>">

                                <div class="col-md-4 col-12">
                                    <div class="form-group">
                                        <label for="">Tanggal Input</label>
                                        <input type="date" class="form-control" name="tgl"
                                            value="<?php echo e($d->tgl); ?>" required>
                                    </div>
                                </div>

                                <div class="col-md-4 col-12">
                                    <div class="form-group">
                                        <label for="">Nomor Berkas</label>
                                        <input type="text" class="form-control" name="no_berkas"
                                            value="<?php echo e($d->no_berkas); ?>" required>
                                    </div>
                                </div>

                                <div class="col-md-4 col-12">
                                    <div class="form-group">
                                        <label for="">Tahun</label>
                                        <input type="text" class="form-control" name="tahun"
                                            value="<?php echo e($d->tahun); ?>" required>
                                    </div>
                                </div>

                                <div class="col-md-4 col-12">
                                    <div class="form-group">
                                        <label for="">Nama Pemohon</label>
                                        <input type="text" class="form-control" name="nm_pemohon"
                                            value="<?php echo e($d->nm_pemohon); ?>" required>
                                    </div>
                                </div>

                                <div class="col-md-4 col-12">
                                    <div class="form-group">
                                        <label for="">Kelurahan</label>
                                        <input type="text" class="form-control" name="kelurahan"
                                            value="<?php echo e($d->kelurahan); ?>" required>
                                    </div>
                                </div>

                                <div class="col-md-4 col-12">
                                    <div class="form-group">
                                        <label for="">Nomor WA</label>
                                        <input type="number" class="form-control" name="no_tlp"
                                            value="<?php echo e($d->no_tlp); ?>" required>
                                    </div>
                                </div>

                                <div class="col-md-4 col-12">
                                    <div class="form-group">
                                        <label for="">Alamat Bidang Tanah</label>
                                        <textarea class="form-control" name="alamat" cols="30" rows="3"><?php echo e($d->alamat); ?></textarea>
                                    </div>
                                </div>

                            </div>

                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                            <button type="submit" class="btn btn-primary">Edit</button>
                        </div>
                    </div>
                </div>
            </div>
        </form>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <div class="modal fade" id="model_lihat_file" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Detail File</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body" id="table_file">

                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>

    



<?php $__env->startSection('script'); ?>
    <script>
        $(document).ready(function() {

            <?php if(session('success')): ?>
            // notification popup
            toastr.options.closeButton = true;
            toastr.options.positionClass = 'toast-top-right';
            toastr.options.showDuration = 1000;
            toastr['success']('<?= session('success') ?>');
            <?php endif; ?>





            <?php if(session('errors')): ?>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                // notification popup
                toastr.options.closeButton = true;
                toastr.options.positionClass = 'toast-top-right';
                toastr.options.showDuration = 1000;
                toastr['error']('<?= $error ?>');
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>

            $(document).on('click', '.btn_lihat_file', function() {

                var url = "<?php echo e(asset('file_upload')); ?>/";
                var file_name = $(this).attr('file_name');
                var jenis_file = file_name.split(".");

                if (jenis_file[1] == 'pdf') {
                    var pdf = '<object data="' + url + file_name +
                        '" type="application/pdf" width="750" height="500"></object>';
                    $("#table_file").html(pdf);
                } else {
                    var image = '<img src="' + url + file_name + '" class="img-fluid">';
                    $("#table_file").html(image);
                }

            });


        });
    </script>
<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\programming\monitoring-pengukuran\resources\views/berkas/loket.blade.php ENDPATH**/ ?>