
<?php $__env->startSection('content'); ?>
    <div id="main-content">
        <div class="container-fluid">
            <div class="block-header">
                <div class="row">
                    <div class="col-12">
                        <h2 class="float-left">Outlet</h2>
                        <button type="button" class="btn btn-primary btn-sm float-right ml-2" data-toggle="modal"
                            data-target="#add-product">
                            <i class="fa fa-plus-circle"></i>
                            Tambah Outlet
                        </button>
                        
                    </div>
                    
                </div>
            </div>

            <div class="row clearfix row-deck">

                <div class="table-responsive">
                    <table class="table js-basic-example dataTable table-custom" id="table">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Outlet</th>
                                <th>Alamat</th>
                                <th>No Telpon</th>
                                <th>Email</th>
                                <th>Event</th>
                                <th>Persen Gaji</th>
                                <th>Aktif</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                                $i = 1;
                            ?>
                            <?php $__currentLoopData = $outlet; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $o): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($i++); ?></td>
                                    <td><?php echo e($o->nama); ?></td>
                                    <td class="text-center"><?php echo e($o->alamat); ?></td>
                                    </td>
                                    <td><?php echo e($o->no_tlpn); ?></td>
                                    <td>
                                        <?php $__currentLoopData = $o->emailCabang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php echo e($e->email); ?> <br>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </td>

                                    <td>
                                        <?php if($o->event == 1): ?>
                                            <p class="text-danger">OFF</p>
                                        <?php else: ?>
                                            <p class="text-success">ON</p>
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo e($o->persen_gaji); ?>%</td>
                                    <td>
                                        <?php if($o->off == 1): ?>
                                            <p class="text-danger">OFF</p>
                                        <?php else: ?>
                                            <p class="text-success">ON</p>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <button type="button" class="btn btn-sm btn-primary mr-2" data-toggle="modal"
                                            data-target="#edit<?php echo e($o->id); ?>">
                                            <i class="fa fa-edit"></i>
                                        </button>

                                        <button type="button" class="btn btn-sm btn-primary" data-toggle="modal"
                                            data-target="#harga<?php echo e($o->id); ?>">
                                            <i class="fa fa-money" aria-hidden="true"></i>
                                        </button>

                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </tbody>
                    </table>
                </div>

            </div>


        </div>
    </div>

    <form action="<?php echo e(route('addOutlet')); ?>" method="post">
        <?php echo csrf_field(); ?>
        <div class="modal fade" id="add-product" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
            aria-hidden="true">
            <div class="modal-dialog modal-lg" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Tambah Outlet</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <div class="row form-group ">

                            <div class="col-12">
                                <div class="form-group row">
                                    <div class=" col-6 mb-2">
                                        <label for="">
                                            <dt>Nama Outlet</dt>
                                        </label>
                                        <input type="text" name="nama" class="form-control" placeholder="Nama Outlet"
                                            required>
                                    </div>

                                    <div class="col-6 mb-2">
                                        <label>Zona Waktu</label>
                                        <select name="time_zone" class="form-control" required>

                                            <option value="Asia/Makassar">WITA</option>
                                            <option value="Asia/Jakarta">WIB</option>

                                        </select>
                                    </div>

                                    <div class="col-lg-6 mb-2">
                                        <label for="">
                                            <dt>Alamat Outlet</dt>
                                        </label>
                                        
                                        <textarea class="form-control" name="alamat" rows="5"></textarea>
                                    </div>

                                    <div class="col-lg-6 mb-2">
                                        <label for="">
                                            <dt>Url Google Map</dt>
                                        </label>
                                        
                                        <textarea class="form-control" name="map" rows="5"></textarea>
                                    </div>



                                    <div class="col-6 mb-2">
                                        <label>Aktif</label>
                                        <select name="off" class="form-control" required>

                                            <option value="0">ON</option>
                                            <option value="1">OFF</option>

                                        </select>
                                    </div>

                                    <div class=" col-6 mb-2">
                                        <label for="">
                                            <dt>Nomor Telpon</dt>
                                        </label>
                                        <input type="number" name="no_tlpn" class="form-control">
                                    </div>


                                    <div class="col-6 mb-2">
                                        <label>Event</label>
                                        <select name="event" class="form-control select2bs4" required>
                                            <option value="0">Tidak</option>
                                            <option value="1">Ya</option>
                                        </select>
                                    </div>

                                    <div class="col-6 mb-2">
                                        <label>Persen gaji</label>
                                        <input type="text" name="persen_gaji" class="form-control" max="100"
                                            required>
                                    </div>

                                    <div class="col-12">
                                        <hr>
                                    </div>


                                    <div class="col-4 mb-2">
                                        <label>Email</label>
                                        <input type="email" name="email[]" class="form-control">
                                    </div>

                                    <div class="col-3 mb-2">
                                        <label>Password</label>
                                        <input type="text" name="password[]" class="form-control">
                                    </div>

                                    <div class="col-4 mb-2">
                                        <label>Keterangan</label>
                                        <input type="text" name="ket[]" class="form-control">
                                    </div>

                                    <div class="col-1 mt-2">
                                        <button type="button" class="btn btn-sm btn-success mt-4" id="tambah-email"><i
                                                class="fa fa-plus"></i></button>
                                    </div>

                                    <div class="col-12 mb-2" id="table_email"></div>

                                    <div class="col-12">
                                        <hr>
                                    </div>

                                    <?php $__currentLoopData = $akun; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="col-8 mb-1">
                                            <input type="hidden" name="akun_id[]" value="<?php echo e($d->id); ?>">
                                            <label for=""><?php echo e($d->nm_akun); ?></label>
                                        </div>
                                        <div class="col-4 mb-1">
                                            <input type="number" name="harga[]" class="form-control" value="0"
                                                required>
                                        </div>
                                        <div class="col-12">
                                            <hr>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </div>


                            </div>



                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary">Tambah</button>
                    </div>
                </div>
            </div>
        </div>
    </form>

    <?php $__currentLoopData = $outlet; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $o): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <!-- Modal -->
        <form action="<?php echo e(route('editOutlet')); ?>" method="post">

            <?php echo method_field('patch'); ?>
            <?php echo csrf_field(); ?>
            <div class="modal fade" id="edit<?php echo e($o->id); ?>" tabindex="-1" role="dialog"
                aria-labelledby="exampleModalLabel" aria-hidden="true">
                <div class="modal-dialog modal-lg" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLabel">Edit Outlet</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body">
                            <div class="row form-group ">
                                <input type="hidden" name="id" value="<?php echo e($o->id); ?>">
                                <div class="col-12">
                                    <div class="form-group row">
                                        <div class=" col-6 mb-2">
                                            <label for="">
                                                <dt>Nama Outlet</dt>
                                            </label>
                                            <input type="text" name="nama" class="form-control"
                                                placeholder="Nama Outlet" value="<?php echo e($o->nama); ?>" required>
                                        </div>

                                        <div class="col-6 mb-2">
                                            <label>Zona Waktu</label>
                                            <select name="time_zone" class="form-control" required>
                                                <?php if($o->time_zone == 'Asia/Makassar'): ?>
                                                    <option value="Asia/Makassar" selected>WITA</option>
                                                    <option value="Asia/Jakarta">WIB</option>
                                                <?php else: ?>
                                                    <option value="Asia/Makassar">WITA</option>
                                                    <option value="Asia/Jakarta" selected>WIB</option>
                                                <?php endif; ?>
                                            </select>
                                        </div>

                                        <div class="col-lg-6 mb-2">
                                            <label for="">
                                                <dt>Alamat Outlet</dt>
                                            </label>
                                            
                                            <textarea class="form-control" name="alamat" rows="5"><?php echo e($o->alamat); ?></textarea>
                                        </div>

                                        <div class="col-lg-6 mb-2">
                                            <label for="">
                                                <dt>Url Google Map</dt>
                                            </label>
                                            
                                            <textarea class="form-control" name="map" rows="5"><?php echo e($o->map); ?></textarea>
                                        </div>



                                        <div class="col-6 mb-2">
                                            <label>Aktif</label>
                                            <select name="off" class="form-control" required>
                                                <?php if($o->off == 1): ?>
                                                    <option value="1" selected>OFF</option>
                                                    <option value="0">ON</option>
                                                <?php else: ?>
                                                    <option value="1">OFF</option>
                                                    <option value="0" selected>ON</option>
                                                <?php endif; ?>
                                            </select>
                                        </div>

                                        <div class="col-12">
                                            <hr>
                                        </div>

                                        <div class="col-4 mb-2">
                                            <label>Email</label>
                                        </div>

                                        <div class="col-3 mb-2">
                                            <label>Password</label>
                                        </div>

                                        <div class="col-4 mb-2">
                                            <label>Keterangan</label>
                                        </div>


                                        <div class="col-1 mt-2">
                                            <label>Hapus</label>
                                        </div>

                                        <?php $__currentLoopData = $o->emailCabang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="col-4 mb-2">
                                                <input type="email" name="email_edit[]" class="form-control"
                                                    value="<?php echo e($e->email); ?>" required>
                                            </div>

                                            <div class="col-3 mb-2">
                                                <input type="text" name="password_edit[]" value="<?php echo e($e->password); ?>"
                                                    class="form-control">
                                            </div>

                                            <div class="col-4 mb-2">
                                                <input type="text" name="ket_edit[]" class="form-control"
                                                    value="<?php echo e($e->ket); ?>">
                                            </div>

                                            <input type="hidden" name="email_id_edit[]" value="<?php echo e($e->id); ?>">

                                            <div class="col-1">
                                                <a href="<?php echo e(route('deleteEmailCabang', $e->id)); ?>"
                                                    onclick="return confirm('Apakah anda yakin ingin menghapus data email?')"
                                                    class="btn btn-sm btn-danger mt-2"><i class="fa fa-trash"></i></a>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                                        <div class="col-12 mb-2" id="table_email_edit"></div>


                                        <div class="col-11"></div>
                                        <div class="col-1 mt-2">
                                            <button type="button" class="btn btn-sm btn-success mt-4"
                                                id="tambah_email_edit"><i class="fa fa-plus"></i></button>
                                        </div>

                                        <div class="col-12">
                                            <hr>
                                        </div>

                                        <div class="col-6 mb-2">
                                            <label>Event</label>
                                            <select name="event" class="form-control select2bs4" required>
                                                <option value="0" <?php echo e($o->event != 1 ? 'selected' : ''); ?>>Tidak
                                                </option>
                                                <option value="1" <?php echo e($o->event == 1 ? 'selected' : ''); ?>>Ya</option>
                                            </select>
                                        </div>

                                        <div class="col-6 mb-2">
                                            <label>Persen gaji</label>
                                            <input type="text" name="persen_gaji" class="form-control" max="100"
                                                value="<?php echo e($o->persen_gaji); ?>" required>
                                        </div>



                                    </div>
                                </div>

                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                            <button type="submit" class="btn btn-primary">Edit</button>
                        </div>
                    </div>
                </div>
            </div>
        </form>

        <form action="<?php echo e(route('editHargaPengeluaran')); ?>" method="post">
            <?php echo csrf_field(); ?>
            <div class="modal fade" id="harga<?php echo e($o->id); ?>" tabindex="-1" role="dialog"
                aria-labelledby="exampleModalLabel" aria-hidden="true">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLabel">Harga</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body">
                            <div class="row">
                                <input type="hidden" name="cabang_id" value="<?php echo e($o->id); ?>">
                                <?php $__currentLoopData = $akun; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php
                                        $ada = 0;
                                    ?>

                                    <?php $__currentLoopData = $o->hargaPengeluaran; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $oh): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($oh->akun_id == $d->id): ?>
                                            <input type="hidden" name="akun_id[]" value="<?php echo e($d->id); ?>">
                                            <div class="col-8 mb-1">
                                                <label for=""><?php echo e($d->nm_akun); ?></label>
                                            </div>
                                            <div class="col-4 mb-1">
                                                <input type="number" name="harga[]" class="form-control"
                                                    value="<?php echo e($oh->harga); ?>">
                                            </div>
                                            <div class="col-12">
                                                <hr>
                                            </div>
                                            <?php
                                                $ada++;
                                            ?>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    <?php if(!$ada): ?>
                                        <input type="hidden" name="akun_id[]" value="<?php echo e($d->id); ?>">
                                        <div class="col-8 mb-1">
                                            <label for=""><?php echo e($d->nm_akun); ?></label>
                                        </div>
                                        <div class="col-4 mb-1">
                                            <input type="number" name="harga[]" class="form-control" value="0">
                                        </div>
                                        <div class="col-12">
                                            <hr>
                                        </div>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                            <button type="submit" class="btn btn-primary">Edit</button>
                        </div>
                    </div>
                </div>
            </div>
        </form>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        $(document).ready(function() {

            <?php if(session('success')): ?>
            // notification popup
            toastr.options.closeButton = true;
            toastr.options.positionClass = 'toast-top-right';
            toastr.options.showDuration = 1000;
            toastr['success']('<?= session('success') ?>');
            <?php endif; ?>



            var count_email = 1;
            $(document).on('click', '#tambah-email', function() {
                count_email = count_email + 1;
                var html_code = '<div class="row" id="row' + count_email + '">';

                html_code +=
                    '<div class="col-4 mb-2"><input type="email" name="email[]" class="form-control"></div>';

                html_code +=
                    '<div class="col-3 mb-2"><input type="text" name="password[]" class="form-control"></div>';

                html_code +=
                    '<div class="col-4 mb-2"><input type="text" name="ket[]" class="form-control"></div>';

                html_code += '<div class="col-1"><button type="button" data-row="row' + count_email +
                    '" class="btn btn-danger btn-sm remove_email">-</button></div>';

                html_code += "</div>";

                $('#table_email').append(html_code);

            });

            $(document).on('click', '.remove_email', function() {
                var delete_row = $(this).data("row");
                $('#' + delete_row).remove();
            });


            var count_email_edit = 1;
            $(document).on('click', '#tambah_email_edit', function() {
                count_email_edit = count_email_edit + 1;
                var html_code = '<div class="row" id="row' + count_email_edit + '">';

                html_code +=
                    '<div class="col-4 mb-2"><input type="email" name="email[]" class="form-control"></div>';

                html_code +=
                    '<div class="col-3 mb-2"><input type="text" name="password[]" class="form-control"></div>';

                html_code +=
                    '<div class="col-4 mb-2"><input type="text" name="ket[]" class="form-control"></div>';

                html_code += '<div class="col-1"><button type="button" data-row="row' + count_email_edit +
                    '" class="btn btn-danger btn-sm remove_email_edit">-</button></div>';

                html_code += "</div>";

                $('#table_email_edit').append(html_code);

            });

            $(document).on('click', '.remove_email_edit', function() {
                var delete_row = $(this).data("row");
                $('#' + delete_row).remove();
            });

        });
    </script>
<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\programming\admin-kebab-keep\resources\views/cabang/index.blade.php ENDPATH**/ ?>