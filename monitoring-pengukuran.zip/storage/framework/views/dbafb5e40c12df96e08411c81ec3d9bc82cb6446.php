<div id="left-sidebar" class="sidebar">
    <button type="button" class="btn-toggle-offcanvas"><i class="fa fa-arrow-left"></i></button>
    <div class="sidebar-scroll">
        <div class="user-account">
            <img src="<?php echo e(asset('img')); ?>/Logo_BPN-KemenATR.png" class="rounded-circle user-photo"
                alt="User Profile Picture">
            <div class="dropdown">
                <span>Welcome,</span>
                <strong><?php echo e(session()->get('name') ? session()->get('name') : ''); ?></strong>
                
                
            </div>
            <hr>
            
        </div>
        <!-- Nav tabs -->
        <ul class="nav nav-tabs">
            <li class="nav-item"><a class="nav-link active" data-toggle="tab" href="#menu">Menu</a></li>
            
            <li class="nav-item"><a class="nav-link" data-toggle="tab" href="#setting"><i class="icon-settings"></i>
                    Setting</a>
            </li>
            
        </ul>

        <!-- Tab panes -->
        <div class="tab-content padding-0">
            <div class="tab-pane active" id="menu">
                <nav id="left-sidebar-nav" class="sidebar-nav">
                    <ul id="main-menu" class="metismenu li_animation_delay">
                        <li class="<?php echo e(Request::is(['/', 'kalender']) ? 'active' : ''); ?>">
                            <a href="javascript:void(0)" class="has-arrow"><i
                                    class="fa fa-dashboard"></i><span>Laporan</span></a>
                            <ul>
                                <li class="<?php echo e(Request::is('/') ? 'active' : ''); ?>"><a
                                        href="<?php echo e(route('home')); ?>">Home</a></li>
                                <li class="<?php echo e(Request::is('kalender') ? 'active' : ''); ?>"><a
                                        href="<?php echo e(route('kalender')); ?>">Kalender</a></li>
                            </ul>
                        </li>

                        <li class="<?php echo e(Request::is(['loket', 'penjadwalan', 'spsBerkas']) ? 'active' : ''); ?>">
                            <a href="javascript:void(0)" class="has-arrow"><i
                                    class="fa fa-address-card"></i><span>Berkas</span></a>
                            <ul>
                                <li class="<?php echo e(Request::is('loket') ? 'active' : ''); ?>"><a
                                        href="<?php echo e(route('loket')); ?>">Input Berkas</a></li>
                                <li class="<?php echo e(Request::is('penjadwalan') ? 'active' : ''); ?>"><a
                                        href="<?php echo e(route('penjadwalan')); ?>">Penjadwalan</a></li>
                                <li class="<?php echo e(Request::is('spsBerkas') ? 'active' : ''); ?>"><a
                                        href="<?php echo e(route('spsBerkas')); ?>">Cetak SPS</a></li>
                                <li class="<?php echo e(Request::is('selesaiSpsBerkas') ? 'active' : ''); ?>"><a
                                        href="<?php echo e(route('selesaiSpsBerkas')); ?>">Selesai SPS</a></li>
                            </ul>
                        </li>

                        <li class="<?php echo e(Request::is(['user']) ? 'active' : ''); ?>">
                            <a href="javascript:void(0)" class="has-arrow"><i
                                    class="fa fa-users"></i><span>Users</span></a>
                            <ul>
                                <li class="<?php echo e(Request::is('user') ? 'active' : ''); ?>"><a
                                        href="<?php echo e(route('user')); ?>">Manajemen User</a></li>
                            </ul>
                        </li>


                        
                    </ul>
                </nav>
            </div>
            
            <div class="tab-pane" id="setting">
                <h6>Choose Skin</h6>
                <ul class="choose-skin list-unstyled">
                    <li data-theme="purple">
                        <div class="purple"></div>
                    </li>
                    <li data-theme="blue">
                        <div class="blue"></div>
                    </li>
                    <li data-theme="cyan" class="active">
                        <div class="cyan"></div>
                    </li>
                    <li data-theme="green">
                        <div class="green"></div>
                    </li>
                    <li data-theme="orange">
                        <div class="orange"></div>
                    </li>
                    <li data-theme="blush">
                        <div class="blush"></div>
                    </li>
                    <li data-theme="red">
                        <div class="red"></div>
                    </li>
                </ul>

                <ul class="list-unstyled font_setting mt-3">
                    <li>
                        <label class="custom-control custom-radio custom-control-inline">
                            <input type="radio" class="custom-control-input" name="font" value="font-nunito"
                                checked="">
                            <span class="custom-control-label">Nunito Google Font</span>
                        </label>
                    </li>
                    <li>
                        <label class="custom-control custom-radio custom-control-inline">
                            <input type="radio" class="custom-control-input" name="font" value="font-ubuntu">
                            <span class="custom-control-label">Ubuntu Font</span>
                        </label>
                    </li>
                    <li>
                        <label class="custom-control custom-radio custom-control-inline">
                            <input type="radio" class="custom-control-input" name="font" value="font-raleway">
                            <span class="custom-control-label">Raleway Google Font</span>
                        </label>
                    </li>
                    <li>
                        <label class="custom-control custom-radio custom-control-inline">
                            <input type="radio" class="custom-control-input" name="font" value="font-IBMplex">
                            <span class="custom-control-label">IBM Plex Google Font</span>
                        </label>
                    </li>
                </ul>

                <ul class="list-unstyled mt-3">
                    <li class="d-flex align-items-center mb-2">
                        <label class="toggle-switch theme-switch">
                            <input type="checkbox">
                            <span class="toggle-switch-slider"></span>
                        </label>
                        <span class="ml-3">Enable Dark Mode!</span>
                    </li>
                    <li class="d-flex align-items-center mb-2">
                        <label class="toggle-switch theme-rtl">
                            <input type="checkbox">
                            <span class="toggle-switch-slider"></span>
                        </label>
                        <span class="ml-3">Enable RTL Mode!</span>
                    </li>
                    <li class="d-flex align-items-center mb-2">
                        <label class="toggle-switch theme-high-contrast">
                            <input type="checkbox">
                            <span class="toggle-switch-slider"></span>
                        </label>
                        <span class="ml-3">Enable High Contrast Mode!</span>
                    </li>
                </ul>

                

                
            </div>
            
        </div>
    </div>
</div>
<?php /**PATH D:\programming\monitoring-pengukuran\resources\views/template/_sidebar.blade.php ENDPATH**/ ?>