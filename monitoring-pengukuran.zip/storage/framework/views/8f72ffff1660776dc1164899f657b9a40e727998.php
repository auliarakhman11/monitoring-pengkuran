<nav class="navbar navbar-fixed-top">
    <div class="container-fluid">
        <div class="navbar-brand">
            <button type="button" class="btn-toggle-offcanvas"><i class="fa fa-bars"></i></button>
            <button type="button" class="btn-toggle-fullwidth"><i class="fa fa-bars"></i></button>
            <a href="">Aplikasi Antrian Petugas Ukur</a>
        </div>

        <div class="navbar-right">
            

            <div id="navbar-menu">
                <ul class="nav navbar-nav">
                    
                    <li>
                        <a href="<?php echo e(route('logout')); ?>" class="icon-menu"><i class="fa fa-power-off"></i></a>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</nav>
<?php /**PATH D:\programming\monitoring-pengukuran\resources\views/template/_navbar.blade.php ENDPATH**/ ?>