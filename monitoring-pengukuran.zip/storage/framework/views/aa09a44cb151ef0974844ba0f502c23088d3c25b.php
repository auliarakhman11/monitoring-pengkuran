<!doctype html>
<html lang="en">

<head>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo e($title); ?> | KantahKabBanjar</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="Iconic Bootstrap 4.5.0 Admin Template">
    <meta name="author" content="WrapTheme, design by: ThemeMakker.com">
    <link rel="icon" type="image/png" href="<?php echo e(asset('img')); ?>/Logo_BPN-KemenATR.png" />

    <!-- VENDOR CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('assets')); ?>/vendor/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo e(asset('assets')); ?>/vendor/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="<?php echo e(asset('assets')); ?>/vendor/toastr/toastr.min.css">
    <link rel="stylesheet" href="<?php echo e(asset('assets')); ?>/vendor/charts-c3/plugin.css" />

    <link rel="stylesheet" href="<?php echo e(asset('assets')); ?>/vendor/jquery-datatable/dataTables.bootstrap4.min.css">
    <link rel="stylesheet"
        href="<?php echo e(asset('assets')); ?>/vendor/jquery-datatable/fixedeader/dataTables.fixedcolumns.bootstrap4.min.css">
    <link rel="stylesheet"
        href="<?php echo e(asset('assets')); ?>/vendor/jquery-datatable/fixedeader/dataTables.fixedheader.bootstrap4.min.css">

    <!-- MAIN Project CSS file -->
    <link rel="stylesheet" href="<?php echo e(asset('assets')); ?>/css/main.css">

    <!-- Select2 -->
    <link rel="stylesheet" href="<?php echo e(asset('assets')); ?>/select2/css/select2.min.css">
    <link rel="stylesheet" href="<?php echo e(asset('assets')); ?>/select2-bootstrap4-theme/select2-bootstrap4.min.css">

    <?php if(!Session::has('name')): ?>
        <script>
            window.location.href = "/logout";
        </script>
    <?php endif; ?>

</head>

<body data-theme="light" class="font-nunito right_icon_toggle">
    <div id="wrapper" class="theme-cyan">

        <!-- Page Loader -->
        <div class="page-loader-wrapper">
            <div class="loader">
                <div class="m-t-30"><img src="<?php echo e(asset('img')); ?>/Logo_BPN-KemenATR.png" width="48" height="48"
                        alt="Iconic">
                </div>
                <p>Please wait...</p>
            </div>
        </div>

        <!-- Top navbar div start -->
        <?php echo $__env->make('template._navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


        <!-- main left menu -->
        <?php echo $__env->make('template._sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


        <!-- rightbar icon div -->
        <div class="right_icon_bar">
            
        </div>

        <!-- mani page content body part -->
        <?php echo $__env->yieldContent('content'); ?>


    </div>
    <!-- Javascript -->
    <script src="<?php echo e(asset('assets')); ?>/bundles/libscripts.bundle.js"></script>
    <script src="<?php echo e(asset('assets')); ?>/bundles/vendorscripts.bundle.js"></script>

    <script src="<?php echo e(asset('assets')); ?>/bundles/datatablescripts.bundle.js"></script>

    <!-- page vendor js file -->
    <script src="<?php echo e(asset('assets')); ?>/vendor/toastr/toastr.js"></script>
    <script src="<?php echo e(asset('assets')); ?>/bundles/c3.bundle.js"></script>

    <!-- page js file -->
    <script src="<?php echo e(asset('assets')); ?>/bundles/mainscripts.bundle.js"></script>
    <script src="<?php echo e(asset('assets')); ?>/html-versiokn/js/index.js"></script>

    <script src="<?php echo e(asset('assets')); ?>/html-versiokn/js/pages/tables/jquery-datatable.js"></script>

    
    <script src="<?php echo e(asset('assets')); ?>/select2/js/select2.full.min.js"></script>

    <?php echo $__env->yieldContent('script'); ?>

    <script type="text/javascript">
        $(document).ready(function() {
            $('.select').select2();

            $('.select2bs4').select2({
                theme: 'bootstrap4'
            });
        });
    </script>

</body>

</html>
<?php /**PATH D:\programming\monitoring-pengukuran\resources\views/template/master.blade.php ENDPATH**/ ?>