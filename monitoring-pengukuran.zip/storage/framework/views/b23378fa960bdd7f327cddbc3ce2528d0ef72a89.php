
<?php $__env->startSection('content'); ?>

    <script src='<?php echo e(asset('fullcalendar')); ?>/dist/index.global.js'></script>



    <style>
        body {
            margin: 40px 10px;
            padding: 0;
            font-family: Arial, Helvetica Neue, Helvetica, sans-serif;
            font-size: 14px;
        }

        #calendar {
            max-width: 1100px;
            margin: 0 auto;
        }
    </style>

    <div id="main-content">
        <div class="container-fluid">
            <div class="block-header">
                <div class="row">
                    <div class="col-12">
                        <h2 class="float-left">Kalender</h2>

                        
                    </div>
                    
                </div>
            </div>

            <div class="row justify-content-center clearfix row-deck">
                <div class="col-12">
                    <div class="card">
                        
                        <div class="card-body">
                            <div id='calendar'></div>
                        </div>
                    </div>
                </div>


            </div>

        </div>
    </div>



    <div class="modal fade" id="model_detail_pengukuran" tabindex="-1" role="dialog" aria-labelledby="exampleModalDetailPengukuran"
        aria-hidden="true">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalDetailPengukuran">Detail Pengukuran</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body" id="table_pengkuran">

                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>

    



<?php $__env->startSection('script'); ?>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            var calendarEl = document.getElementById('calendar');

            var pengukuran = JSON.parse(`<?php echo $dt_p; ?>`);

            console.log(pengukuran);
            

            var calendar = new FullCalendar.Calendar(calendarEl, {
                headerToolbar: {
                    left: 'prev,next today',
                    center: 'title',
                    right: 'dayGridMonth,timeGridWeek,timeGridDay'
                },
                initialDate: "<?php echo e(date('Y-m-d')); ?>",
                navLinks: true, // can click day/week names to navigate views
                selectable: true,
                selectMirror: true,
                // select: function(arg) {
                //     var title = prompt('Event Title:');
                //     if (title) {
                //         calendar.addEvent({
                //             title: title,
                //             start: arg.start,
                //             end: arg.end,
                //             allDay: arg.allDay
                //         })
                //     }
                //     calendar.unselect()
                // },
                eventClick: function(arg) {
                    // if (confirm('Are you sure you want to delete this event?')) {
                    //     arg.event.remove()
                    // }
                    console.log(arg.event.id);
                    $('#table_pengkuran').html('<div class="spinner-border text-primary" role="status"><span class="visually-hidden"></span></div>');
                    $.get('detailPengukuran/' + arg.event.id, function (data) {
                        $('#table_pengkuran').html(data);
                    });

                    $('#model_detail_pengukuran').modal('show');

                },
                editable: true,
                dayMaxEvents: true, // allow "more" link when too many events
                // events: [{
                //         title: 'All Day Event',
                //         start: '2023-01-01'
                //     },
                //     {
                //         title: 'Long Event',
                //         start: '2023-01-07',
                //         end: '2023-01-10'
                //     },
                //     {
                //         groupId: 999,
                //         title: 'Repeating Event',
                //         start: '2023-01-09T16:00:00'
                //     },
                //     {
                //         groupId: 999,
                //         title: 'Repeating Event',
                //         start: '2023-01-16T16:00:00'
                //     },
                //     {
                //         title: 'Conference',
                //         start: '2023-01-11',
                //         end: '2023-01-13'
                //     },
                //     {
                //         title: 'Meeting',
                //         start: '2023-01-12T10:30:00',
                //         end: '2023-01-12T12:30:00'
                //     },
                //     {
                //         title: 'Lunch',
                //         start: '2023-01-12T12:00:00'
                //     },
                //     {
                //         title: 'Meeting',
                //         start: '2023-01-12T14:30:00'
                //     },
                //     {
                //         title: 'Happy Hour',
                //         start: '2023-01-12T17:30:00'
                //     },
                //     {
                //         title: 'Dinner',
                //         start: '2023-01-12T20:00:00'
                //     },
                //     {
                //         title: 'Birthday Party',
                //         start: '2023-01-13T07:00:00'
                //     },
                //     {
                //         title: 'Click for Google',
                //         url: 'http://google.com/',
                //         start: '2023-01-28'
                //     }
                // ]
                events: pengukuran
            });

            calendar.render();
        });
    </script>
    <script>
        $(document).ready(function() {

            <?php if(session('success')): ?>
            // notification popup
            toastr.options.closeButton = true;
            toastr.options.positionClass = 'toast-top-right';
            toastr.options.showDuration = 1000;
            toastr['success']('<?= session('success') ?>');
            <?php endif; ?>





            <?php if(session('errors')): ?>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                // notification popup
                toastr.options.closeButton = true;
                toastr.options.positionClass = 'toast-top-right';
                toastr.options.showDuration = 1000;
                toastr['error']('<?= $error ?>');
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>

            

        });
    </script>
<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\programming\monitoring-pengukuran\resources\views/laporan/kalender.blade.php ENDPATH**/ ?>