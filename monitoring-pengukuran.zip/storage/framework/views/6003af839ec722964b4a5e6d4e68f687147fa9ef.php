<table class="table table-sm">
    <thead>
        <tr>
            <td>Tanggal</td>
            <td><?php echo e(date('d/m/Y', strtotime($berkas->tgl_pengukuran))); ?></td>
        </tr>
        <tr>
            <td>Pemohon</td>
            <td><?php echo e($berkas->nm_pemohon); ?></td>
        </tr>
        <tr>
            <td>Kelurahan/Desa</td>
            <td><?php echo e($berkas->kelurahan); ?></td>
        </tr>
        <tr>
            <td>Alamat</td>
            <td><?php echo e($berkas->alamat); ?></td>
        </tr>
        <tr>
            <td>No WA</td>
            <td><a href="https://api.whatsapp.com/send?phone=62<?php echo e(substr($berkas->no_tlp, 1)); ?>"
                                                target="_blank"><?php echo e($berkas->no_tlp); ?></a></td>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td>Petugas Ukur</td>
            <td>
                <?php $__currentLoopData = $berkas->pengukuran; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    - <?php echo e($p->petugas->name); ?><br>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </td>
        </tr>
    </tbody>
</table><?php /**PATH D:\programming\monitoring-pengukuran\resources\views/laporan/detail_pengukuran.blade.php ENDPATH**/ ?>